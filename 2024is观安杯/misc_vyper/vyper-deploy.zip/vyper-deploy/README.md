The infra shouldn't be vulnerable.
It's not necessary to look at anywhere other than the vyper file `src/contracts/vyper_hacker.vy` to solve this challenge!

Start the local challenge server:
```
docker compose up --build
```
