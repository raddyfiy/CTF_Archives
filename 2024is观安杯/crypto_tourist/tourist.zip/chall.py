
import signal
import socketserver
from Crypto.Util.number import *
from hashlib import md5
from os import urandom
import base64
import random
import string
from secret import FLAG

class Challenge:
    def __init__(self):
        self.p = getPrime(1024)
        self.q = getPrime(1024)
        self.n = self.p * self.q
        self.phi = (self.p - 1) * (self.q - 1)
        self.user_db = []

    def save(self, username, keyint):
        key = long_to_bytes(keyint)
        key_commit = md5(key).digest()
        username_int = bytes_to_long(username)
        username_enc = pow(username_int, keyint, self.n) 
        self.user_db.append((username_enc, key_commit))

    def check(self, index, keyint):
        key = long_to_bytes(keyint)
        assert md5(key).digest() == self.user_db[index][1], "Invalid key"
        username_enc = self.user_db[index][0]
        d = inverse(keyint, self.phi)
        username_dec = pow(username_enc, d, self.n)
        username = base64.b64encode(long_to_bytes(username_dec)).decode()
        assert "FLAG" in username, "Not Admin"

class Task(socketserver.BaseRequestHandler):
    def __init__(self, *args, **kargs):
        super().__init__(*args, **kargs)

    def timeout_handler(self, signum, frame):
        raise TimeoutError

    def dosend(self, msg):
        try:
            self.request.sendall(msg.encode("latin-1") + b"\n")
        except:
            pass

    def rigister(self):
        self.dosend(f"Give me your key: ")
        buf = b""
        while len(buf) < 1000:
            buf += self.request.recv(1)
            if buf[-1:] == b"\n":
                break
        your_key = buf.decode()
        your_key_int = int(your_key, 16)
        self.dosend(f"Give me your username: ")
        buf = b""
        while len(buf) < 10:
            buf += self.request.recv(1)
            if buf[-1:] == b"\n":
                break
        buf = buf[:-1]
        assert b"tourist" in buf, "Not tourist"
        assert len(buf) <= 8, "Too long"
        self.chall.save(buf, your_key_int)

    def get_flag(self):
        self.dosend(f"Give me your key: ")
        buf = b""
        while len(buf) < 1000:
            buf += self.request.recv(1)
            if buf[-1:] == b"\n":
                break
        your_key = buf.decode()
        your_key_int = int(your_key, 16)
        self.dosend(f"Give me your index: ")
        buf = b""
        while len(buf) < 1000:
            buf += self.request.recv(1)
            if buf[-1:] == b"\n":
                break
        index = int(buf.decode())
        print(index, your_key_int)
        self.chall.check(index, your_key_int)
        self.dosend(f"FLAG: {FLAG}")

    def handle(self):
        try: 
            signal.signal(signal.SIGALRM, self.timeout_handler)
            self.chall = Challenge()
            self.dosend(f"p = {self.chall.p}")
            self.dosend(f"q = {self.chall.q}")
            signal.alarm(600)
            while True:
                self.dosend(f"1. Rigister")
                self.dosend(f"2. Get Flag")
                self.dosend(f"3. Exit")
                buf = b""
                while len(buf) < 1000:
                    buf += self.request.recv(1)
                    if buf[-1:] == b"\n":
                        break
                choice = int(buf)
                if choice == 1:
                    self.rigister()
                elif choice == 2:
                    self.get_flag()
                elif choice == 3:
                    self.request.close()
                    return
                else:
                    self.dosend("Invalid")
        except TimeoutError:
            self.dosend("Timeout")
            return
        except Exception as e:
            print(e)
            self.dosend("WTF?")
            self.request.close()



class ThreadedServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    pass


if __name__ == "__main__":
    HOST, PORT = "0.0.0.0", 10500
    server = ThreadedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()
